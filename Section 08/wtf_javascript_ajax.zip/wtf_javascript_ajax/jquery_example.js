$.ajax(function() {
    headers = {'X-CSRFToken' : $('#csrf_token').val() },
    ...
});