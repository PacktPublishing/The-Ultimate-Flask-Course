from flask import Flask 
from flask_mail import Mail, Message

def create_app():
    app = Flask(__name__)

    app.config['MAIL_SERVER'] = 'smtp.fastmail.com'
    app.config['MAIL_PORT'] = 465
    app.config['MAIL_USERNAME'] = 'support@prettyprinted.com'
    app.config['MAIL_PASSWORD'] = 'quf2fx2mcz3kxkrb'
    app.config['MAIL_USE_TLS'] = False
    app.config['MAIL_USE_SSL'] = True
    app.config['MAIL_DEFAULT_SENDER'] = 'support@prettyprinted.com'

    mail = Mail()
    mail.init_app(app)

    @app.route('/')
    def index():
        msg = Message('Multiple Recipients', recipients=['hefile1549@dfb55.com', 'tbjabyopn8@privacy-mail.top'])
        msg.add_recipient('l7h01n+hp2hk5gk9ktc@sharklasers.com')
        #msg.body = 'This is plaintext in the message!'
        msg.html = '<b>This is an HTML message!</b>'
        mail.send(msg)

        return '<h1>Sent!</h1>'

    return app