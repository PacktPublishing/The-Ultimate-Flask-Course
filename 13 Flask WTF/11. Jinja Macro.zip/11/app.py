from flask import Flask, render_template
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, IntegerField, BooleanField
from wtforms.validators import InputRequired, Length, AnyOf, Email

class LoginForm(FlaskForm):
    username = StringField('username', validators=[
        InputRequired('Input required!'),
        Length(min=3, max=8, message='Your message is not the required length.'),
    ])
    password = PasswordField('password', validators=[
        InputRequired(),
        AnyOf(values=['secret', 'password'])
    ])
    age = IntegerField('age', default=24)
    yesno = BooleanField('yesno')
    email = StringField('email', validators=[Email()])

class User:
    def __init__(self, username, age, email):
        self.username = username
        self.age = age
        self.email = email

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'Mysecret!'
    app.config['WTF_CSRF_ENABLED'] = True
    app.config['WTF_CSRF_SECRET_KEY'] = 'Mycsrfsecret'
    app.config['WTF_CSRF_TIME_LIMIT'] = 3600

    @app.route('/', methods=['GET', 'POST'])
    def index():
        user = User(username='John', age=50, email='john@yahoo.com')
        print('BEFORE')
        print(user.username)
        print(user.age)
        print(user.email)
        form = LoginForm(obj=user)

        if form.validate_on_submit():
            form.populate_obj(user)
            print('AFTER')
            print(user.username)
            print(user.age)
            print(user.email)
            return f'<h1>Username: {form.username.data} Password: {form.password.data} Age: {form.age.data} Yes/No: {form.yesno.data} Email: {form.email.data}</h1>'

        return render_template('index.html', form=form)

    return app